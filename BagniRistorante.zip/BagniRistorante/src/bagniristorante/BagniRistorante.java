/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bagniristorante;

/**
 *
 * @author Asus
 */
public class BagniRistorante {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BagnoUomini a1=new BagnoUomini(true,"uomo");
        Thread b1=new BagnoDonne(false,"donna");
        a1.start();
        b1.start();
    }
    
}
